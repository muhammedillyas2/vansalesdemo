// import 'dart:ui';
//
// import 'package:charts_flutter/flutter.dart' as charts;
// import 'package:flutter/material.dart';
//
// class PieChartModel {
//   String day;
//   String category;
//   int sales;
//   final charts.Color color;
//
//   PieChartModel({ this.day,this.category,
//     this.sales,
//     this.color,}
//       );
// }
