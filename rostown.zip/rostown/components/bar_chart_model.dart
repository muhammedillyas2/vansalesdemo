// import 'dart:ui';
//
// import 'package:charts_flutter/flutter.dart' as charts;
// import 'package:flutter/material.dart';
//
// class BarChartModel {
//   String day;
//   String hours;
//   int sales;
//   final charts.Color color;
//
//   BarChartModel({ this.day,this.hours,
//     this.sales,
//     this.color,}
//       );
// }
